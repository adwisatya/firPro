FreshNews theme by FThemes, http://fthemes.com
Online Demo: http://fthemes.com/demo/FreshNews/
Theme URI: http://fthemes.com/freshnews-free-wordpress-theme/