<div id="sidebarindeks">
	<table cellpadding="20px" >
		<tr>
			<td valign="top">
				<h2>About Us </h2>
				<h3>Our Mission</h3>
				<h4>is to deliver finest engineering designs and analysis in all our business lines with verified & validated methods for fulfillment of regulations and our clients’needs</h4>
				<h3>Our Values</h3>
				<h4>Innovation – as the world evolves, upcoming engineering problems and challenges alter, thus enforcing us to seek more effective and efficient methods to tackle every projects. Thus ensuring us to serve the finest engineering service at any given time.
				</h4>
			</td>
		</tr>
	</table>
</div>
    
