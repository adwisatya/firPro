
    <div id="footer">
        <div id="copyrights" style="background-color:#b0c4de;width:1000px;">
            <table width="600px">
                <tr>
                    <td width="200px" align="left">
                       <h2>Services</h2>
					   <h4>CIVIL ENGINEERING</h4>
					   <h4>MARINE ENGINEERING</h4>
					   <h4>METOCEAN & HYDRODYNAMICS ANALYSIS</h4>
					   <h4>STRUCTURAL ANALYSIS</h4>

                    </td>
                    <td width="200px" align="left">
                       <h2>Portofolio</h2>
					   <h4>Sediment Transport Study & Analysis</h4>
					   <h4>Metocean Data Integration Study</h4>
					   <h4>Integrity Analysis of BOG</h4>
					   <h4>North Shore Housing Restoration Fund.</h4>					   
                    </td>
                    <td width="200px" align="left">
                       <h2>Contact Us</h2>
                        <h4>A. Yani 510H Bandung 40122 Indonesia</h4>
                        <h4>022-93395826</h4>
                        <h4>022-93395825</h4>
                        <h4>email: contacts@ilpi-eng.com</h4>
                    </td>
                </tr>
            </table>
        </div>
        <div id="credits">Powered by <a href="http://wordpress.org/"><strong>WordPress</strong></a> | Theme Designed by: <?php echo wp_theme_credits(0); ?>  | Thanks to <?php echo wp_theme_credits(1); ?>, <?php echo wp_theme_credits(2); ?> and <?php echo wp_theme_credits(3); ?></div><!-- #credits -->
    </div><!-- #footer -->
 
</body>
</html>