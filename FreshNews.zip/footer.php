
    <div align="center">
		<div id="copyrights">
			<div id="footer-kiri">
					<h3>Services</h3>
					<p>CIVIL ENGINEERING</p>
					<p>MARINE ENGINEERING</p>
					<p>METOCEAN & HYDRODYNAMICS ANALYSIS
					STRUCTURAL ANALYSIS</p>
			</div>
			<div id="footer-tengah" align="center">
			</div>
			<div id="footer-kanan">
				<h3>Contact Us</h3>
				<p>A. Yani 510H Bandung 40122 Indonesia</p>
				<p>022-93395826</p>
				<p>022-93395825</p>
				<p>email: contacts@ilpi-eng.com</p>			
			</div>
        </div>
        <div id="credits">Powered by <a href="http://wordpress.org/"><strong>WordPress</strong></a> | Theme Designed by: <?php echo wp_theme_credits(0); ?>  | Thanks to <?php echo wp_theme_credits(1); ?>, <?php echo wp_theme_credits(2); ?> and <?php echo wp_theme_credits(3); ?></div><!-- #credits -->
	</div><!-- #footer -->
 </div>
</body>
</html>