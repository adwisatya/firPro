<?php
/**
 * Template Name: AboutUs
*/

global $theme; get_header(); ?>

    <div id="main-fullwidth" >
	<font face="Arial">
	<img src="<?php echo get_template_directory_uri(); ?>/images/aboutus/banneraboutus.jpg"></img>
		<table width=960px > 
		<td width=700px>
			<a href="/">Home</a> > About Us
			<h2> About Us</h2>
			<img src="<?php echo get_template_directory_uri(); ?>/images/aboutus/bannermini.jpg" ></img>
			<p> is to deliver finest engineering designs and analysis in all our business lines with verified & validated methods for fulfillment of regulations and our clients needs</p>
			</br>
					<img src="<?php echo get_template_directory_uri(); ?>/images/aboutus/bannermini2.jpg"></img>
					<h3> innovation</h3>
					<p>as the world evolves, upcoming engineering problems and challenges alter, thus enforcing us to seek more effective and efficient methods to tackle every projects. Thus ensuring us to serve the finest engineering service at any given time.</p>
					<h3> integrity</h3>
					<p>in order to achieve finest results and maintain relationships with our customers, we always include integrity in highest priority of our ethics</p>		
		</td>
		<td>
			<h3>Civil Engineering:</h3>
			<img src="<?php echo get_template_directory_uri(); ?>/images/aboutus/civileng.jpg" width="85%" height="85%"></img>
			<h3>Marine Engineering: </h3>
			<img src="<?php echo get_template_directory_uri(); ?>/images/aboutus/marineeng.jpg" width="85%" height="85%"></img>
		</td>
		</table>
    </div><!-- #main-fullwidth -->
<?php get_footer(); ?>